#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
using namespace std;

class Account {
private:
    int dogecoin, balance;
    int bitcoin;
    int deposit, withdraw;
    int total_equity;
    int dogecoin_value;
    int bitcoin_value;
    int crypto_invest;
    int crypto_return;
    vector<pair<string, int>> transactions;

public:
    Account() {
        total_equity = 100;
        balance = 50000;
        dogecoin = 0;
        bitcoin = 0;
        withdraw = 0;
        deposit = 0;
        dogecoin_value = 100;
        bitcoin_value = 500;
        crypto_invest = 0;
        crypto_return = 0;
    }

    void Deposit(int money) {
        deposit += money;
        balance += money;
        transactions.push_back({"Deposit:", money});
    }

    void GetAccountInformation() {
        cout << "Money Details:\n";
        cout << "Bank Balance: " << balance << endl;
        cout << "Dogecoin: " << dogecoin << endl;
        cout << "Bitcoin: " << bitcoin << endl;
    }

    bool Withdraw(int money) {
        if (money > balance) {
            return false;
        }

        withdraw += money;
        balance -= money;
        transactions.push_back({"Withdraw:", money});
        return true;
    }

    bool BuyCrypto() {
        int option;
        cout << "Want to purchase Dogecoin, press 1. For Bitcoin, press 2: ";
        cin >> option;

        if (total_equity != 0) {
            srand(time(NULL));
            int luck = rand();

            if (luck % 251 == 0) {
                if (option == 1) {
                    dogecoin += 1;
                    balance -= dogecoin_value;
                    crypto_invest += dogecoin_value;
                }
                else {
                    bitcoin += 1;
                    balance -= bitcoin_value;
                    crypto_invest += bitcoin_value;
                }
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }

        return true;
    }

    bool SellCrypto() {
        int option;
        cout << "Want to sell Dogecoin, press 1. For Bitcoin, press 2: ";
        cin >> option;

        if (option == 2) {
            if (bitcoin == 0)
                return false;
            crypto_return += bitcoin_value;
            balance += bitcoin_value;
            transactions.push_back({"Bitcoin Sold:", bitcoin_value});
            bitcoin -= 1;
        }
        else {
            if (dogecoin == 0)
                return false;
            crypto_return += dogecoin_value;
            balance += dogecoin_value;
            transactions.push_back({"Dogecoin Sold:", dogecoin_value});
            dogecoin -= 1;
        }

        return true;
    }

    void History() {
        cout << "Displaying All transactions:\n";
        for (const auto& it : transactions) {
            cout << it.first << " " << it.second << endl;
        }

        char temp;
        cout << "Do you want to clear all transactions (Y/N): ";
        cin >> temp;

        int no = transactions.size();

        if (temp == 'Y' || temp == 'y') {
            transactions.clear();
            cout << "Total transactions cleared: " << no << endl;
        }
        else {
            cout << "Total transactions: " << no << endl;
        }
    }
};

int main() {
    Account person;
    int amount, choice;

    while (true) {
        cout << "\n**************************************************\n\n";
        cout << "Press 1 to view your Account Info\n";
        cout << "Press 2 to deposit money\n";
        cout << "Press 3 to withdraw money\n";
        cout << "Press 4 to view your transaction history\n";
        cout << "Press 5 to view your Buy Crypto options\n";
        cout << "Press 6 to view your Sell Crypto options\n";
        cout << "Press any other key to exit\n\n";
        cout << "**************************************************\n\n";

        cin >> choice;

        switch (choice) {
            case 1:
                person.GetAccountInformation();
                break;

            case 2:
                cout << "Enter amount to deposit: ";
                cin >> amount;
                person.Deposit(amount);
                cout << "Successfully deposited money" << endl;
                break;

            case 3:
                cout << "Enter amount to withdraw: ";
                cin >> amount;
                if (person.Withdraw(amount)) {
                    cout << "Successfully withdrawn amount" << endl;
                } else {
                    cout << "Not Enough Balance" << endl;
                }
                break;

            case 4:
                person.History();
                break;

            case 5:
                if (person.BuyCrypto()) {
                    cout << "Successful Transaction" << endl;
                } else {
                    cout << "Better Luck next time" << endl;
                }
                break;

            case 6:
                if (person.SellCrypto()) {
                    cout << "Successful Transaction" << endl;
                } else {
                    cout << "Not Enough Cryptocoins" << endl;
                }
                break;

            default:
                exit(0);
        }
    }

    return 0;
}
